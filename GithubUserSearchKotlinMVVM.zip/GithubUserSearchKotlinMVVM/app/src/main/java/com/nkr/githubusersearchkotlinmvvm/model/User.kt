package com.nkr.githubusersearchkotlinmvvm.model

data class User(
    val login : String,
    val avatar_url : String,
    val html_url : String
)
