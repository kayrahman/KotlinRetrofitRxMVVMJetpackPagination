package com.nkr.githubusersearchkotlinmvvm.network


/** The base URL of the API */
const val GITHUB_BASE_URL = "https://api.github.com"