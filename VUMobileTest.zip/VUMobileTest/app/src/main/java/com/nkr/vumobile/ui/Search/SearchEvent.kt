package com.nkr.vumobile.ui.Search

sealed class SearchEvent{
   object OnStart : SearchEvent()
}