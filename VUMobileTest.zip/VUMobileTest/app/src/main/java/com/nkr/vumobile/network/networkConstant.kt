package com.nkr.vumobile.network


/** The base URL of the API */

const val BASE_URL = "https://reqres.in/api/"